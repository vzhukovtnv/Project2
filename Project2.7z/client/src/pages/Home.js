import Navbar from "../components/Navbar"
  
const Home = () => {
    return ( 
        <div >
            <Navbar pageName="Home" />
        </div>
     );
}
 
export default Home;