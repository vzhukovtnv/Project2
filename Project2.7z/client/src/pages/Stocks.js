import Navbar from "../components/Navbar"
const Stocks = () => {
    return (
        <div >
            <Navbar pageName="Stocks" />

            <div >
                <h1>Admin</h1>
            </div>
        </div>
    );
}

export default Stocks;
