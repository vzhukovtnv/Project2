import Navbar from "../components/Navbar"
const Admin = () => {
    return (
        <div >
            <Navbar pageName="Admin" />

            <div >
                <h1>Admin</h1>
            </div>
        </div>
    );
}

export default Admin;
