const operations =  require('../business/operations');
id ="60aab2a2b4296b30c891bd3f"

operations.buy(id,"AMD",2,1).then((c) => console.log(c));