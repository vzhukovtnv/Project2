module.exports = {
    testEnvironment: 'node'
}